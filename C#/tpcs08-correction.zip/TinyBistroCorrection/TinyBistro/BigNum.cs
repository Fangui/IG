﻿using System;
using System.Collections.Generic;

namespace TinyBistro
{
    public class BigNum
    {
        private List<int> digits_;

        public BigNum(string source)
        {
            int i = 0;
            digits_ = new List<int>();

            for (; i < source.Length; i++)
                AddDigit(source[i] - '0');

            digits_.Reverse();

            while (digits_.Count > 0 && digits_[digits_.Count - 1] == 0)
                digits_.RemoveAt(digits_.Count - 1);
        }

        public int GetNumDigits()
        {
            return digits_.Count;
        }

        public void AddDigit(int digit)
        {
            digits_.Add(digit);
        }

        public void SetDigit(int digit, int position)
        {
            if (digits_.Count <= position)
            {
                for (int i = digits_.Count; i <= position; i++)
                    AddDigit(0);
            }
            digits_[position] = digit;
            while (digits_.Count > 0 && digits_[digits_.Count - 1] == 0)
                digits_.Remove(0);
        }

        public int GetDigit(int position)
        {
            if (position >= digits_.Count || position < 0)
                throw new OverflowException("This digit is outside the number of digits");
            return digits_[position];
        }

        public static BigNum operator +(BigNum a, BigNum b)
        {
            BigNum result = new BigNum("0");

            int size1 = a.digits_.Count;
            int size2 = b.digits_.Count;
            int i = 0;

            int mem = 0;

            while (i < size1 || i < size2)
            {
                int number = mem;
                if (i < size1)
                    number += a.digits_[i];
                if (i < size2)
                    number += b.digits_[i];

                Console.WriteLine("number = " + number + " and i = " + i);
                result.SetDigit(number % 10, i);
                mem = number / 10;
                i++;
            }
            result.SetDigit(mem, i);

            return result;
        }

        public static BigNum operator -(BigNum a, BigNum b)
        {

            BigNum result = new BigNum("");
            int size1 = a.digits_.Count;
            int size2 = b.digits_.Count;
            int i = 0;

            int mem = 0;

            while (i < size1)
            {
                int number = a.digits_[i] - mem;
                if (i < size2)
                    number -= b.digits_[i];
                if (number < 0)
                {
                    number += 10;
                    mem = 1;
                }
                else
                    mem = 0;
                result.SetDigit(number, i);
                i++;
            }
            return result;
        }

        public static BigNum operator *(BigNum a, BigNum b)
        {
            BigNum result = new BigNum("");

            for (int i = 0; i < b.digits_.Count; i++)
            {
                int carry = b.GetDigit(i);
                int wh = 0;
                int last = 0;
                for (int j = 0; j < a.digits_.Count; j++)
                {
                    int old = i + j < result.digits_.Count ?
                        result.GetDigit(i + j) : 0;
                    int num = a.digits_[j] * carry + wh + old;
                    wh = 0;
                    if (num >= 10)
                    {
                        wh = num / 10;
                        num = num % 10;
                    }

                    result.SetDigit(num, i + j);

                    last = j;
                }
                if (wh != 0)
                    result.SetDigit(wh, last + i + 1);
            }

            return result;
        }

        public static bool operator >(BigNum a, BigNum b)
        {
            if (a.digits_.Count < b.digits_.Count)
                return false;
            if (a.digits_.Count > b.digits_.Count)
                return true;

            int i = a.digits_.Count;
            while (i != 0)
            {
                i--;
                if (a.digits_[i] != b.digits_[i])
                    return a.digits_[i] > b.digits_[i];
            }
            return false;
        }

        public static bool operator <(BigNum a, BigNum b)
        {
            if (a > b || a.digits_ == b.digits_)
                return false;

            return true;
        }

        public static bool operator==(BigNum a, BigNum b)
        {
            if (a.digits_.Count != b.digits_.Count)
                return false;

            for (int i = 0; i < a.digits_.Count; i++)
            {
                if (a.digits_[i] != b.digits_[i])
                    return false;
            }

            return true;
        }

        public static bool operator !=(BigNum a, BigNum b)
        {
            return !(a == b);
        }

        public override bool Equals(object obj)
        {
            return this == (BigNum)obj;
        }

        public override int GetHashCode()
        {
            return 1;
        }

        public static BigNum operator /(BigNum a, BigNum b)
        {
            if (b.digits_.Count == 0)
                throw new OverflowException("Error: division by 0.");

            BigNum result = new BigNum("");
            if (b > a)
                return result;

            BigNum carry = new BigNum("");
            int i = a.digits_.Count;

            do
            {
                carry.digits_.Insert(0, a.digits_[--i]);

                while (carry > b || carry == b)
                {
                    while (carry.digits_.Count != 0 && carry.digits_[carry.digits_.Count - 1] == 0)
                        carry.digits_.Remove(0);
                    if (carry.digits_.Count != 0)
                    {
                        carry = carry - b;
                        if (result.digits_.Count <= i)
                            result.SetDigit(1, i);
                        else
                            result.digits_[i] += 1;
                    }
                }
            } while (i > 0);

            return result;
        }

        public static BigNum operator %(BigNum a, BigNum b)
        {
            if (b.digits_.Count == 0)
                throw new OverflowException("Error: division by 0.");

            BigNum result = new BigNum("");
            if (b > a)
                return result;

            BigNum carry = new BigNum("");
            int i = a.digits_.Count;

            do
            {
                carry.digits_.Insert(0, a.digits_[--i]);

                while (carry > b || carry == b)
                {
                    while (carry.digits_.Count != 0 && carry.digits_[carry.digits_.Count - 1] == 0)
                        carry.digits_.Remove(0);
                    if (carry.digits_.Count != 0)
                    {
                        carry = carry - b;
                        if (result.digits_.Count <= i)
                            result.SetDigit(1, i);
                        else
                            result.digits_[i] += 1;
                    }
                }
            } while (i > 0);

            return carry;
        }

        public void Print()
        {
            if (digits_.Count == 0)
                Console.Write('0');
            for (int i = digits_.Count - 1; i >= 0; i--)
                Console.Write(digits_[i]);

            Console.WriteLine();
        }
    }
}
