﻿using System;
using System.IO;

namespace TinyBistro
{
    public static class Parser
    {
        public static void Parse()
        {
            StreamReader sr = new StreamReader("operation.txt");
            string num1 = "";
            string num2 = "";

            while (sr.Peek() != '-' && sr.Peek() != '+' && sr.Peek() != '/' && sr.Peek() != '*' && sr.Peek() != '%')
            {
                num1 += sr.Read() - '0';
            }

            char op = Convert.ToChar(sr.Read());
            Console.WriteLine("op = " + op);

            while (!sr.EndOfStream)
                num2 += sr.Read() - '0';

            Console.WriteLine("num1 = " + num1);
            Console.WriteLine("num2 = " + num2);

            BigNum bn1 = new BigNum(num1);
            BigNum bn2 = new BigNum(num2);
            
            BigNum res;
            if (op == '+')
                res = bn1 + bn2;
            else if (op == '-')
                res = bn1 - bn2;
            else if (op == '*')
                res = bn1 * bn2;
            else if (op == '/')
                res = bn1 / bn2;
            else if (op == '%')
                res = bn1 % bn2;
            else
                res = new BigNum("0");

            Console.Write("result of operation = ");
            res.Print();
        }
    }
}
