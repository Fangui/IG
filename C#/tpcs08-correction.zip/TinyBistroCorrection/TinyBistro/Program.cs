﻿using System;

namespace TinyBistro
{
    class Program
    {
        static void Main(string[] args)
        {
            Parser.Parse();

            Console.ReadKey();
        }
    }
}
