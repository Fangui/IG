﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpcs03_correction
{
    class Program
    {
        static void drawme(int size)
        {
            if (size < 1)
                return;

            Console.WriteLine("  .n.");
            Console.WriteLine(" /___\\");
            Console.WriteLine(" | |o|");
            Console.WriteLine("IIIIIII");

            while (size != 0)
            {
                Console.WriteLine(" |  /|");
                Console.WriteLine(" | / |");
                if (size == 1)
                    Console.WriteLine(" |/__|");
                else
                    Console.WriteLine(" |/  |");
                size--;
            }
        }

        static int pow(int a, int n)
        {
            int res = 1;

            while (n > 0)
            {
                res *= a;
                n--;
            }

            return res;
        }

        static void ask()
        {
            string ok = "";
            do
            {
                Console.Write("Please write 'ok': ");
                ok = Console.ReadLine();
            } while (ok != "ok");
            Console.Write("Congrat!");
        }

        static void simple_loop(int[] A)
        {
            for (int i = 0; i < A.Length; ++i)
            {
                Console.Write(A[i] + " ");
            }
            Console.WriteLine();
        }

        static void double_loop(int[,] A)
        {
            Console.WriteLine(" ---------");
            for (int i = 0; i < 3; ++i)
            {
                for (int j = 0; j < 3; ++j)
                {
                    Console.Write("| " + A[i, j] + " ");
                }
                Console.Write("|\n");

            }
            Console.WriteLine(" ---------");

        }

        static void double_loop2(int[,] A)
        {
            Console.WriteLine(" ---------");
            for (int i = 0; i < 3; ++i)
            {
                for (int j = 0; j < 3; ++j)
                {
                    Console.Write("| " + A[j, i] + " ");
                }
                Console.Write("|\n");

            }
            Console.WriteLine(" ---------");
        }

        static bool missing_line(int k, int i, int[][] grid)
        {
            for (int j = 0; i < grid.Length; j++)
            {
                if (grid[i][j] == k)
                    return false;
            }
            return true;
        }

        static bool missing_column(int k, int i, int[][] grid)
        {
            for (int j = 0; i < grid.Length; j++)
            {
                if (grid[j][i] == k)
                    return false;
            }
            return true;
        }

        static bool missing_blk(int k, int i, int j, int[][] grid)
        {
            for (int x = 0; x < 3; ++x)
            {
                for (int y= 0; y < 3; ++y)
                {
                    if (grid[(i * 3) + x][(j * 3) + y] == k)
                        return false;
                }
            }
            return true;
        }

        static void next(ref int i, ref int j)
        {
            j++;
            if (j == 10)
            {
                j = 0;
                i++;
            }
        }

        static bool solve(int[][] grid, int i, int j)
        {
            if (grid[i][j] != 0)
            {
                next(ref i, ref j);
                return solve(grid, i, j + 1);
            }
            else if (i == 9 || j == 9)
                return true;
            else
            {
                int si = i;
                int sj = j;
                next(ref i, ref j);
                for (int x = 1; x < 10; ++i)
                {
                    if (missing_line(x, si, grid) && missing_column(x, sj, grid) && missing_blk(x, si / 3, sj / 3, grid))
                    {
                        grid[si][sj] = x;
                        if (solve(grid, i, j))
                            return true;
                    }
                }
            }
            return false;
        }

        static void Main(string[] args)
        {
            
            Console.Read();
        }
    }
}
