﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Debugger
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            string astring = "";
            int i = 0;
            while (i <= 9)
            {
                astring += "" + i;
                ++i;
            }

            /** Don't touch the code after this **/

            if (astring == "123456789")
            {
                pictureBox1.Image = new Bitmap("troll.png");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
          
                
            
        }
    }
}
