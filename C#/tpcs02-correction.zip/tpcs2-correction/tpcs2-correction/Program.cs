﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TP2
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = args[0];

            if (s == "1")
            {
                Console.WriteLine("Exercise 1:");
                Hello();
            }
            else if (s == "2")
            {
                Console.WriteLine("Exercise 2:");
                Echo();
            }
            else if (s == "3")
            {
                Console.WriteLine("Exercise 3:");
                MyConsole();
            }
            else if (s == "4")
            {
                Console.WriteLine("Exercise 4:");
                NegativeCount();
            }
            else if (s == "6")
            {
                Console.WriteLine("Exercise 6:");
                Morse();
            }
            else if (s == "6bonus")
            {
                Console.WriteLine("Exercise 6 Bonus:");
                MorseIte();
            }
            else if (s == "7")
            {
                Console.WriteLine("Exercise 7:");
                Pine(3);
                Console.WriteLine();
                Pine(5);
            }
            else
                Console.WriteLine("Fail - Not a valid name");
            Console.ReadKey();
        }


        static void Hello()
        {
            Console.WriteLine("Hello World!");
        }

        static void Echo()
        {
            Console.WriteLine("Write something!");
            string s = Console.ReadLine();
            Console.WriteLine(s);
        }

        static void MyConsole()
        {
            Console.BackgroundColor = ConsoleColor.DarkCyan;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Title = "This is my own console!";
            Console.WriteLine("              _____   _____     _____  \n     /\\      / ____| |  __ \\   / ____| \n    /  \\    | |      | |  | | | |      \n   / /\\ \\   | |      | |  | | | |      \n  / ____ \\  | |____  | |__| | | |____  \n /_/    \\_\\  \\_____| |_____/   \\_____| \n                                       ");
            Console.ResetColor();
        }

        static void NegativeCount()
        {
            int i = 3;
            while (i >= 0)
            {
                Console.WriteLine(i);
                i--;
            }
        }



        static void Morse()
        {
            string s = ".... . .-.. .-.. ---  .-- --- .-. .-.. -..";
            Console.WriteLine(s);
            MorseRec(s, 0);
        }

        static void MorseRec(string s, int i)
        {
            if (i < s.Length)
            {
                if (s[i] == '.')
                    Console.Beep(900, 150);
                else if (s[i] == '-')
                    Console.Beep(900, 450);
                else
                    System.Threading.Thread.Sleep(450);

                MorseRec(s, i + 1);
            }
        }

        static void MorseIte()
        {
            string s = ".... . .-.. .-.. ---  .-- --- .-. .-.. -..";
            Console.WriteLine(s);
            int i = 0;
            while (i < s.Length)
            {
                if (s[i] == '.')
                    Console.Beep(900, 150);
                else if (s[i] == '-')
                    Console.Beep(900, 450);
                else
                    System.Threading.Thread.Sleep(450);
                i++;
            }
        }

        static void Pine(int n)
        {
            if (n < 3)
            {
                Console.WriteLine("Too small :(");
                return;
            }
            int i = 1;
            while (i <= n)
            {
                string s = "";
                for (int nb_space = 0; nb_space < n - i; nb_space++)
                    s += ' ';

                for (int nb_star = 0; nb_star < (2 * i) - 1; nb_star++)
                    s += '*';
                Console.WriteLine(s);
                i++;
            }
            i = 1;
            while (i <= n / 3)
            {
                string s = "";
                for (int nb_space = 0; nb_space < n - 1; nb_space++)
                    s += ' ';
                s += '*';
                Console.WriteLine(s);
                i++;
            }
        }

    }
}
