﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /* ------------------- Text Modifier Functions ----------------------*/
        public delegate string MyFun(int a, int b);
        
        private void call_isCool(string promo, Label result)
        {
            int year;

            if (int.TryParse(promo, out year))
                result.Text = Functions.CoolOrNot(year);
            else
                result.Text = "This is not a number.";
        }

        private void call_isOlderOrBetter(string promoA, string promoB,
                                            Label result, MyFun f)
        {
            int yearA, yearB;

            if (int.TryParse(promoA, out yearA)
                && int.TryParse(promoB, out yearB))
                result.Text = f(yearA, yearB);
            else
                result.Text = "At least one of them is not a number.";
        }

        /* ----------------- Event Handler Functions ----------------------*/
        private void btn_isCoolPromoA_Click(object sender, EventArgs e)
        {
            call_isCool(textBoxPromoA.Text, text_isCoolPromoA);
        }

        private void btn_isCoolPromoB_Click(object sender, EventArgs e)
        {
            call_isCool(textBoxPromoB.Text, text_isCoolPromoB);
        }

        private void btn_isOlder_Click(object sender, EventArgs e)
        {
            call_isOlderOrBetter(textBoxPromoA.Text, textBoxPromoB.Text,
                text_OlderBetter, Functions.Older);
        }

        private void btn_isBetter_Click(object sender, EventArgs e)
        {
            call_isOlderOrBetter(textBoxPromoA.Text, textBoxPromoB.Text,
                text_OlderBetter, Functions.Better);
        }

        private void btn_swap_Click(object sender, EventArgs e)
        {
            Functions.Swap(textBoxPromoA, textBoxPromoB);
        }

    }
}
