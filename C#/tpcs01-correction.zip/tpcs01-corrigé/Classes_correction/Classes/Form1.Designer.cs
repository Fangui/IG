﻿namespace Classes
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxPromoA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPromoB = new System.Windows.Forms.TextBox();
            this.btn_isCoolPromoA = new System.Windows.Forms.Button();
            this.text_isCoolPromoA = new System.Windows.Forms.Label();
            this.btn_isCoolPromoB = new System.Windows.Forms.Button();
            this.text_isCoolPromoB = new System.Windows.Forms.Label();
            this.btn_isBetter = new System.Windows.Forms.Button();
            this.btn_swap = new System.Windows.Forms.Button();
            this.btn_isOlder = new System.Windows.Forms.Button();
            this.text_OlderBetter = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxPromoA
            // 
            this.textBoxPromoA.Location = new System.Drawing.Point(24, 31);
            this.textBoxPromoA.Name = "textBoxPromoA";
            this.textBoxPromoA.Size = new System.Drawing.Size(141, 20);
            this.textBoxPromoA.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Class of";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(274, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Class of";
            // 
            // textBoxPromoB
            // 
            this.textBoxPromoB.Location = new System.Drawing.Point(251, 31);
            this.textBoxPromoB.Name = "textBoxPromoB";
            this.textBoxPromoB.Size = new System.Drawing.Size(133, 20);
            this.textBoxPromoB.TabIndex = 2;
            // 
            // btn_isCoolPromoA
            // 
            this.btn_isCoolPromoA.Location = new System.Drawing.Point(24, 57);
            this.btn_isCoolPromoA.Name = "btn_isCoolPromoA";
            this.btn_isCoolPromoA.Size = new System.Drawing.Size(141, 39);
            this.btn_isCoolPromoA.TabIndex = 4;
            this.btn_isCoolPromoA.Text = "How are those student ?";
            this.btn_isCoolPromoA.UseVisualStyleBackColor = true;
            this.btn_isCoolPromoA.Click += new System.EventHandler(this.btn_isCoolPromoA_Click);
            // 
            // text_isCoolPromoA
            // 
            this.text_isCoolPromoA.AutoSize = true;
            this.text_isCoolPromoA.Location = new System.Drawing.Point(21, 99);
            this.text_isCoolPromoA.Name = "text_isCoolPromoA";
            this.text_isCoolPromoA.Size = new System.Drawing.Size(0, 13);
            this.text_isCoolPromoA.TabIndex = 5;
            // 
            // btn_isCoolPromoB
            // 
            this.btn_isCoolPromoB.Location = new System.Drawing.Point(251, 57);
            this.btn_isCoolPromoB.Name = "btn_isCoolPromoB";
            this.btn_isCoolPromoB.Size = new System.Drawing.Size(133, 39);
            this.btn_isCoolPromoB.TabIndex = 6;
            this.btn_isCoolPromoB.Text = "How are those student ?";
            this.btn_isCoolPromoB.UseVisualStyleBackColor = true;
            this.btn_isCoolPromoB.Click += new System.EventHandler(this.btn_isCoolPromoB_Click);
            // 
            // text_isCoolPromoB
            // 
            this.text_isCoolPromoB.AutoSize = true;
            this.text_isCoolPromoB.Location = new System.Drawing.Point(248, 99);
            this.text_isCoolPromoB.Name = "text_isCoolPromoB";
            this.text_isCoolPromoB.Size = new System.Drawing.Size(0, 13);
            this.text_isCoolPromoB.TabIndex = 7;
            // 
            // btn_isBetter
            // 
            this.btn_isBetter.Location = new System.Drawing.Point(251, 183);
            this.btn_isBetter.Name = "btn_isBetter";
            this.btn_isBetter.Size = new System.Drawing.Size(133, 38);
            this.btn_isBetter.TabIndex = 8;
            this.btn_isBetter.Text = "Which one is better ?";
            this.btn_isBetter.UseVisualStyleBackColor = true;
            this.btn_isBetter.Click += new System.EventHandler(this.btn_isBetter_Click);
            // 
            // btn_swap
            // 
            this.btn_swap.Location = new System.Drawing.Point(167, 127);
            this.btn_swap.Name = "btn_swap";
            this.btn_swap.Size = new System.Drawing.Size(81, 39);
            this.btn_swap.TabIndex = 9;
            this.btn_swap.Text = "Swap them !";
            this.btn_swap.UseVisualStyleBackColor = true;
            this.btn_swap.Click += new System.EventHandler(this.btn_swap_Click);
            // 
            // btn_isOlder
            // 
            this.btn_isOlder.Location = new System.Drawing.Point(24, 183);
            this.btn_isOlder.Name = "btn_isOlder";
            this.btn_isOlder.Size = new System.Drawing.Size(141, 39);
            this.btn_isOlder.TabIndex = 10;
            this.btn_isOlder.Text = "Which is older ?";
            this.btn_isOlder.UseVisualStyleBackColor = true;
            this.btn_isOlder.Click += new System.EventHandler(this.btn_isOlder_Click);
            // 
            // text_OlderBetter
            // 
            this.text_OlderBetter.AutoSize = true;
            this.text_OlderBetter.Location = new System.Drawing.Point(21, 225);
            this.text_OlderBetter.Name = "text_OlderBetter";
            this.text_OlderBetter.Size = new System.Drawing.Size(0, 13);
            this.text_OlderBetter.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 253);
            this.Controls.Add(this.text_OlderBetter);
            this.Controls.Add(this.btn_isOlder);
            this.Controls.Add(this.btn_swap);
            this.Controls.Add(this.btn_isBetter);
            this.Controls.Add(this.text_isCoolPromoB);
            this.Controls.Add(this.btn_isCoolPromoB);
            this.Controls.Add(this.text_isCoolPromoA);
            this.Controls.Add(this.btn_isCoolPromoA);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxPromoB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPromoA);
            this.Name = "Form1";
            this.Text = "Class Quality Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPromoA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPromoB;
        private System.Windows.Forms.Button btn_isCoolPromoA;
        private System.Windows.Forms.Label text_isCoolPromoA;
        private System.Windows.Forms.Button btn_isCoolPromoB;
        private System.Windows.Forms.Label text_isCoolPromoB;
        private System.Windows.Forms.Button btn_isBetter;
        private System.Windows.Forms.Button btn_swap;
        private System.Windows.Forms.Button btn_isOlder;
        private System.Windows.Forms.Label text_OlderBetter;
    }
}

