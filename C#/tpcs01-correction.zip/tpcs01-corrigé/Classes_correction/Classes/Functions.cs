﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public static class Functions
    {
        private static string AreSame()
        {
            return "These classes are the same.";
        }

        private static string NotExist(int n)
        {
            if (n == 1)
                return "This class doesn't exist.";
            return "At least one class does not exist.";
        }

        private static string XOlderThanY(int X, int Y)
        {
            return "Class of " + X + " is older than class of " + Y + ".";
        }

        private static string BothGreatButXBetter(int X)
        {
            return "Both are great, but class of " + X 
                + " is better, thanks to the ancients’ wisdom.";
        }

        private static string XBetterThanY(int X, int Y)
        {
            return "Class of " + X + " seems to be better than class "
                + "of " + Y + ".";
        }

        private static string UnbeatableX(int X)
        {
            string[] s = 
            { 
                "You cannot test class of " + X + ".", 
                "Class of " + X + " is surely great."
            };
            Random r = new Random();
            return s[r.Next(s.Length)];
        }

        /*------------------------- Exercises -----------------------------*/
        public static void Swap(TextBox A, TextBox B)
        {
            string temp = A.Text;
            A.Text = B.Text;
            B.Text = temp;
        }

        public static bool IsValid(int year)
        {
            return year >= 1989 && year <= 2020;
        }

        public static bool IsEven(int n)
        {
            return n % 2 == 0;
        }

        private static bool IsOP(int n)
        {
            return n % 2018 == 0;
        }

        public static string CoolOrNot(int year)
        {
            if (IsValid(year))
            {
                if (IsOP(year))
                    return UnbeatableX(year);
                else if (IsEven(year))
                    return "They should be cool !";
                else
                    return "Well, they are less likely to be cool.";
            }
            else
                return NotExist(1) + (year > 2020 ? ".. Yet." : ""); // Bonus here
        }


        public static string Older(int yearA, int yearB)
        {
            if (IsValid(yearA) && IsValid(yearB))
            {
                if (yearA == yearB)
                    return AreSame();
                else if (yearA < yearB)
                    return XOlderThanY(yearA, yearB);
                else
                    return XOlderThanY(yearB, yearA);
            }
            else
                return NotExist(2);
        }


        public static string Better(int yearA, int yearB)
        {
            if (IsValid(yearA) && IsValid(yearB))
            {
                if (yearA == yearB)
                    return AreSame();

                // When both are even or odd, the oldest is slightly better
                else if (!(IsEven(yearA) ^ IsEven(yearB)) || (IsOP(yearA) && IsOP(yearB)))
                {
                    if (yearA < yearB)
                        return BothGreatButXBetter(yearA);
                    else
                        return BothGreatButXBetter(yearB);
                }
                // Bonus here
                else if (IsOP(yearA))
                    return UnbeatableX(yearA);
                else if (IsOP(yearB))
                    return UnbeatableX(yearB);

                // Even year is always better than odd year
                else if (IsEven(yearA))
                    return XBetterThanY(yearA, yearB);
                else
                    return XBetterThanY(yearB, yearA);
            }
            else
                return NotExist(2);
        }

        /*----------------------- END Exercises -----------------------------*/
    }
}
