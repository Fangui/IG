﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calc
{
    public partial class Form1 : Form
    {
        double[] operand = { 0, 0 };
        int cur_operand = 0;
        double prev_result = 0;
        char op = '+';

        public Form1()
        {
            InitializeComponent();
            Operand_Update();
        }

        private void Operand_Update()
        {
            screen.Text = operand[cur_operand].ToString();
        }

        private void ClickFigure(int n)
        {
            if (cur_operand == 0 && operand[0] == prev_result)
                operand[0] = 0;
            operand[cur_operand] *= 10;
            operand[cur_operand] += n;
            Operand_Update();
        }

        private void OperatorToMode(bool mode)
        {
            buttonPlus.Enabled = mode;
            buttonMinus.Enabled = mode;
            buttonMult.Enabled = mode;
            buttonDiv.Enabled = mode;
            buttonSqrt.Enabled = mode;
            buttonFact.Enabled = mode;
            buttonFibo.Enabled = mode;
            buttonPow.Enabled = mode;
            buttonMod.Enabled = mode;
            buttonGcd.Enabled = mode;
            buttonRotN.Enabled = mode;
        }

        private void TwoOperandOperator(char op)
        {
            cur_operand++;
            this.op = op;
            OperatorToMode(false);
        }

        private void button0_Click(object sender, EventArgs e)
        {
            ClickFigure(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ClickFigure(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClickFigure(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ClickFigure(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ClickFigure(4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ClickFigure(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClickFigure(6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ClickFigure(7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ClickFigure(8);

        }

        private void button9_Click(object sender, EventArgs e)
        {
            ClickFigure(9);
        }

        private void buttonPlus_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('+');
        }

        private void buttonMult_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('*');
        }

        private void buttonMinus_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('-');
        }

        private void buttonDiv_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('/');
        }

        private void buttonMod_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('%');
        }

        private void buttonGcd_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('g');
        }

        private void buttonPow_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('^');
        }

        private void buttonFact_Click(object sender, EventArgs e)
        {
            op = '!';
            Equal();
        }

        private void buttonFibo_Click(object sender, EventArgs e)
        {
            op = 'f';
            Equal();
        }

        private void buttonSqrt_Click(object sender, EventArgs e)
        {
            op = 'v';
            Equal();
        }

        private void EndOperation()
        {
            cur_operand = 0;
            operand[0] = prev_result;
            operand[1] = 0;
            op = '+';
            Operand_Update();
            OperatorToMode(true);
        }

        public static double RotNString(double A, int N)
        {
            string S = A.ToString();

            string s = "";
            for (int i = 0; i < S.Length; i++)
                s += Functions.RotN(S[i], N);
            double res = A;
            try
            {
                res = Convert.ToDouble(s);
            }
            catch (FormatException e)
            {
                Console.WriteLine("{0} has invalid format for RotN", e.Source);  
            }
            return res;
        }

        private void Equal()
        {
            switch (op)
            {
                case 'f':
                    prev_result = Functions.Fibo(operand[0]);
                    break;
                case '!':
                    prev_result = Functions.Fact(operand[0]);
                    break;
                case 'v':
                    prev_result = Functions.Sqrt(operand[0]);
                    break;
                case '^':
                    prev_result = Functions.PowOpti((int)operand[0],
                                                   (int)operand[1]);
                    break;
                case 'g':
                    prev_result = Functions.Gcd((int)operand[0],
                                                (int)operand[1]);
                    break;
                case 'r':
                    prev_result = RotNString(operand[0],
                                                (int)operand[1]);
                    break;
                default:
                    prev_result = Functions.BasicOp(operand[0], operand[1],
                                                   op);
                    break;
            }
            EndOperation();
        }

        private void buttonEqual_Click(object sender, EventArgs e)
        {
            Equal();
        }

        private void buttonRotN_Click(object sender, EventArgs e)
        {
            TwoOperandOperator('r');
        }

    }
}
