﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calc
{
    public static class Functions
    {
        public static double BasicOp(double A, double B, char op)
        {
            switch (op)
            {
                case '+':
                    return A + B;
                case '-':
                    return A - B;
                case '*':
                    return A * B;
                case '/':
                    return A / B;
                case '%':
                    return B != 0 ? A % B : 0;
                default:
                    return 0;
            }
        }

        public static double Fact(double A)
        {
            return A <= 0 ? 1 : A * Fact(A - 1);
        }

        public static double Fibo(double A)
        {
            return A <= 1 ? A : Fibo(A - 1) + Fibo(A - 2);
        }
   
        public static double PowNaive(double A, double B)
        {
            return B == 0 ? 1 : A * PowNaive(A, B - 1);
        }

        public static int PowOpti(int A, int B)
        {
            if (B < 0)
                return PowOpti(1 / A, -B);
            if (B <= 1)
                return B == 0 ? 1 : A;
            if (B % 2 == 0)
                return PowOpti(A * A, B / 2);
            return A * PowOpti(A * A, (B - 1) / 2);
        }

        public static double Gcd(int A, int B)
        {
            if (B == 0)
                return A;

            int r = A % B;
            if (r == 0)
                return B;
            return Gcd(B, r);
        }

        private static double Abs(double A)
        {
            return A < 0 ? -A : A;
        }

        private static double RecSqrt(double A, double vA)
        {
            if (A <= 0)
                return 0;
            
            double precision = 0.0001;
            if (Abs(A - vA * vA) < precision)
                return vA;
            return RecSqrt(A, (vA + A / vA) / 2);
        }

        public static double Sqrt(double A)
        {
            return RecSqrt(A, A);
        }

        public static char RotN(char C, int N)
        {
            int res = (C - '0' + N ) % 10;
            char c = (char)(res + '0');
            return c;
        }
    }
}
