﻿using System;

namespace WhatTheHex
{
    using typeElement = Tuple<float, Tuple<int, int>>;

    public class AI
    {
        int max_games_analysed = 150;
        int max_depth = 2;
        int color;
        Random rand;

        public AI(int color)
        {
            rand = new Random();
            this.color = color;
        }

        public AI(int color, int max_games_analysed, int max_depth) : this(color)
        {
            this.max_games_analysed = max_games_analysed;
            this.max_depth = max_depth;
        }

        public typeElement minimax(Tree<typeElement> tree, int depth)
        {
            if (depth == max_depth)
                return tree.Value;
            typeElement res = minimax(tree.getChild(0), depth + 1);
            for (int i = 1; i < tree.nbChild(); ++i)
            {
                float newValue = minimax(tree.getChild(i), depth + 1).Item1;
                if ((depth % 2 == 0 && newValue > res.Item1)
                    || (depth % 2 == 1 && newValue < res.Item1))
                    res = tree.getChild(i).Value;
            }
            tree.Value = res;
            return res;
        }

        float monteCarlo(int[,] board, int color)
        {
            float res = 0f;
            int nb;
            bool finished;
            int currentColor;
            int[,] tmp = new int[gameInfo.row, gameInfo.column];
            for (int i = 0; i < max_games_analysed; ++i)
            {
                for (int k = 0; k < gameInfo.row; ++k)
                    for (int j = 0; j < gameInfo.column; ++j)
                        tmp[k, j] = board[k, j];
                currentColor = color;
                finished = gameInfo.isFinished(tmp) != 0;
                while (!finished)
                {
                    nb = rand.Next(gameInfo.column * gameInfo.row);
                    while (tmp[nb / gameInfo.column, nb % gameInfo.row] != 0)
                        nb = (nb + 1) % (gameInfo.column * gameInfo.row);
                    tmp[nb / gameInfo.column, nb % gameInfo.row] = currentColor;
                    finished = gameInfo.isFinished(tmp) != 0;
                    currentColor = currentColor % 2 + 1;
                }
                if (currentColor != this.color)
                    res += 1f;
            }
            return res /= max_games_analysed;
        }

        void build_tree(Tree<typeElement> tree, int[,] board, int depth)
        {
            if (depth == max_depth)
            {
                tree.Value = Tuple.Create(monteCarlo(board, depth % 2 == 0 ? color : color % 2 + 1), tree.Value.Item2);
                return;
            }
            for (int i = 0; i < gameInfo.row; ++i)
            {
                for (int j = 0; j < gameInfo.column; ++j)
                {
                    if (board[i, j] == 0)
                    {
                        board[i, j] = depth % 2 == 0 ? this.color : this.color % 2 + 1;
                        tree.addChild(new Tree<typeElement>(Tuple.Create(0f, Tuple.Create(i, j))));
                        build_tree(tree.getChild(tree.nbChild() - 1), board, depth + 1);
                        board[i, j] = 0;
                    }
                }
            }
        }

        public Tuple<int, int> play(int[,] board)
        {
            Tree<typeElement> tree = new Tree<typeElement>(Tuple.Create(0f, Tuple.Create(0, 0)));
            int nbCells = gameInfo.nbCells(board);
            int tmp = max_depth;
            if (nbCells < max_depth)
                max_depth = nbCells;
            build_tree(tree, board, 0);
            typeElement res = minimax(tree, 0);
            max_depth = tmp;
            return res.Item2;
        }
    }
}