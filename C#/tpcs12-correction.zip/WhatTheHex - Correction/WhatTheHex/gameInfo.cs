﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WhatTheHex
{
    public static class gameInfo
    {
        public enum player
        {
            HUMAN,
            AI
        };

        public static Cell[,] cells;
        public static int[,] board;

        // ============== Board settings
        public static Board winForm;
        public static int scale = 27;
        public static bool horizontal = true;

        public static int grid_space = 2;
        public static int row = 5;
        public static int column = row;
        public static int start_x = 0;
        public static int start_y = (int)(column * scale * (horizontal ? 1.1 : 1.5));


        public static int currentPlayer = 1;

        public static player[] players = { player.HUMAN, player.HUMAN };

        public static bool finished = false;
        private static int currentVisit = 5;

        public static AI[] HAL = { new AI(1), new AI(2) };
        public static bool debuged = false;

        public static void playAI()
        {
            Tuple<int, int> play = HAL[currentPlayer - 1].play(board);
            takeCell(currentPlayer, play.Item1, play.Item2);
        }

        public static int isFinished(int[,] board)
        {
            if (isFinished(2, board))
                return 2;
            if (isFinished(1, board))
                return 1;
            return 0;
        }

        public static bool isFinished(int player, int[,] board)
        {
            currentVisit += 1;
            int iteMax = (player == 1 ? row : column);

            for (int ite = 0; ite < iteMax; ite++)
            {
                if (recFinish(player == 1 ? ite : 0,
                              player == 2 ? ite : 0, player, board))
                    return true;
            }
            return false;
        }
        private static bool recFinish(int x, int y, int player, int[,] tmp)
        {
            // Check Borders
            if (x >= row || x < 0
                || y >= column || y < 0)
                return false;

            // Check if we already visited that cell
            // Check if we aren't the owner of the cell
            if (cells[x, y].visited == currentVisit
                || tmp[x, y] != player)
                return false;

            // Mark as visited
            cells[x, y].visited = currentVisit;

            // did we reach the other border ?
            if ((player == 1 && y == (column - 1))
                || (player == 2 && x == (row - 1)))
                return true;

            // Check surrounding cells, Clockwise
            if (recFinish(x - 1, y + 1, player, tmp)
                || recFinish(x, y + 1, player, tmp)
                || recFinish(x + 1, y, player, tmp)
                || recFinish(x + 1, y - 1, player, tmp)
                || recFinish(x, y - 1, player, tmp)
                || recFinish(x - 1, y, player, tmp))
                return true;
            return false;

        }

        private static bool isPreviousCellVisited(int ite)
        {
            if (ite == 0)
                return false;
            if (currentPlayer == 1)
                return board[ite, 0] == 1;
            return board[0, ite] == currentPlayer;
        }

        public static void debugDisplay()
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    if (debuged)
                        cells[i, j].Text = "";
                    else
                        cells[i, j].Text = i.ToString() + ":" + j.ToString();
                }
            }
            debuged = !debuged;
        }
        public static int nbCells(int[,] board)
        {
            int nb = 0;
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    if (board[i, j] == 0)
                        nb++;
                }
            }
            return nb;
        }

        // ============== GAME
        public static void makeBoard(Board form)
        {
            // Create Hexatons
            cells = new Cell[row, column];
            board = new int[row, column];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cells[i, j] = new Cell(i, j);
                    board[i, j] = 0;
                    form.Controls.Add(cells[i, j]);
                }
            }

            // Set Size
            form.Size = new Size(
                cells[row - 1, column - 1].Location.X + scale * 5,
                cells[row - 1, 0].Location.Y + scale * 6);

            // Anchors, allowing resizing
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cells[i, j].Anchor = AnchorStyles.Bottom & AnchorStyles.Right;
                }
            }
        }

        public static void restart()
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cells[i, j].restart();
                    board[i, j] = 0;
                }
            }
            winForm.ResetBackColor();
            currentPlayer = 1;
            finished = false;
        }

        public static void takeCell(int player, int x, int y)
        {
            if (!finished)
            {
                board[x, y] = player;
                cells[x, y].changeColor(Cell.getColorMouseClick());
                finished = isFinished(gameInfo.board) != 0;
                if (finished)
                    changeWinColor(currentPlayer);
                currentPlayer = currentPlayer % 2 + 1;
            }
        }

        private static void changeWinColor(int player)
        {
            winForm.BackColor = Cell.getColorMouseHover();
        }
    }
}