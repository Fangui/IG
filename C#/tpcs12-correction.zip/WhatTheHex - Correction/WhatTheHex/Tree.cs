﻿using System;

namespace WhatTheHex
{
    public class Tree<Element>
    {
        private System.Collections.Generic.List<Tree<Element>> childs;
        private Element element;

        public Tree(Element element)
        {
            childs = new System.Collections.Generic.List<Tree<Element>>();
            this.element = element;
        }

        public Element Value
        {
            get { return element; }
            set { element = value; }
        }

        public void addChild(Tree<Element> child)
        {
            childs.Add(child);
        }

        public Tree<Element> getChild(int child)
        {
            return childs[child];
        }

        public int nbChild()
        {
            return childs.Count;
        }

        public void print()
        {
            System.Console.Write(element);
            System.Console.Write(" < ");
            int max = childs.Count - 1;
            for (int i = 0; i < max; ++i)
            {
                childs[i].print();
                System.Console.Write(", ");
            }
            if (max >= 0)
                childs[max].print();
            System.Console.Write(" >");
        }
    }
}

