﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze
{
    class Program
    {
        static void Main(string[] args)
        {
            Maze m = new Maze(10, 10, 0, 0, 9, 9);
            m.generate();
            m.solve();
            m.display();

            Console.ReadKey();
        }
    }
}
