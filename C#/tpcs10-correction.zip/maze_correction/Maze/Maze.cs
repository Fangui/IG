﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze
{

    enum Type
    {
        START, //The start of the maze
        END, //The end of the maze
        PATH, //For the cells which belong to the path once the maze solved
        NONE //Default type
    };

    class Maze
    {
        private uint width; //Width of the maze
        private uint height; //Height of the maze
        private Cell[,] maze; //Array (dimension 2) which contains all ths cells
        private Tuple<uint, uint> posStart; //The position (x, y) of the start
        private Random r; //A random number generator

        public Maze(uint width, uint height, uint xStart, uint yStart, uint xEnd, uint yEnd)
        {
            r = new Random();
            this.width = width;
            this.height = height;
            maze = new Cell[width, height];
            posStart = new Tuple<uint, uint>(xStart, xStart);
            for (uint x = 0; x < width; x++)
                for (uint y = 0; y < height; y++)
                {
                    if (x == xStart && y == yStart)
                        maze[x, y] = new Cell(Type.START);
                    else if (x == xEnd && y == yEnd)
                        maze[x, y] = new Cell(Type.END);
                    else
                        maze[x, y] = new Cell();
                }

        }

        #region Display
        private string verticalWall(uint x1, uint x2, uint y)
        {
            if (x2 < width && x1 < width && x2 >= 0 && x1 >= 0 && maze[x1, y].isLinked(x2, y))
            {
                if (maze[x1, y].getType() == Type.PATH && maze[x2, y].getType() == Type.PATH)
                    return "X";
                return " ";
            }
                
            return "|";
        }

        private string horizontalWall(uint x, uint y1, uint y2)
        {
            if (y2 < height && y1 < height && y2 >= 0 && y1 >= 0 && maze[x, y1].isLinked(x, y2))
            {
                if (maze[x, y1].getType() == Type.PATH && maze[x, y2].getType() == Type.PATH)
                    return "XX";
                return "  ";
            }
                
            return "--";
        }

        public void display()
        {
            for (uint x = 0; x < width; x++) // first row
            {
                Console.Write("+--");
            }
            Console.Write("+\n");


            for (uint y = 0; y < height; y++)
            {
                Console.Write("|"); // first column
                string s = "";
                for (uint x = 0; x < width; x++)
                {
                    s += maze[x, y].display();
                    s += verticalWall(x, x + 1, y);
                }
                s += "\n+";
                for (uint x = 0; x < width; x++)
                {
                    s += horizontalWall(x, y, y + 1) + "+";
                }
                Console.WriteLine(s);
            }
        }
        #endregion


        #region Generation
        public void generate()
        {
            uint x = (uint)r.Next(0, (int)width);
            uint y = (uint)r.Next(0, (int)height);

            generateRec(x, y);
        }
        private void generateRec(uint x, uint y)
        {
            if (maze[x, y].getVisited())
                return;
           
            maze[x, y].setVisited(true);
            if (maze[x, y].getType() == Type.START || maze[x, y].getType() == Type.END)
                return;
            List<Tuple<uint,uint>> n = getNotVisitedNeighbor(x, y);
            while (n.Count != 0)
            {
                int i = r.Next(n.Count);
                Tuple<uint, uint> t = n.ElementAt<Tuple<uint, uint>>(i);
                maze[x, y].addLink(t);
                maze[t.Item1, t.Item2].addLink(new Tuple<uint, uint>(x, y));
                generateRec(t.Item1, t.Item2);
                n = getNotVisitedNeighbor(x,y);
            }
        }
        private List<Tuple<uint, uint>> getNotVisitedNeighbor(uint x, uint y)
        {
            List<Tuple<uint, uint>> n = new List<Tuple<uint, uint>>();
            if (x > 0 && !maze[x - 1, y].getVisited())
                n.Add(new Tuple<uint, uint>(x - 1, y));
            if (x < width - 1 && !maze[x + 1, y].getVisited())
                n.Add(new Tuple<uint, uint>(x + 1, y));
            if (y > 0 && !maze[x, y - 1].getVisited())
                n.Add(new Tuple<uint, uint>(x, y - 1));
            if (y < height - 1 && !maze[x, y + 1].getVisited())
                n.Add(new Tuple<uint, uint>(x, y + 1));
            return n;
        }
        #endregion


        #region Solve
        private void cleanVisited()
        {
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    maze[x, y].setVisited(false);
                }
            }
        }

        public void solve()
        {
            cleanVisited();
            solveRec(posStart.Item1,posStart.Item2);
        }

        private bool solveRec(uint x, uint y)
        {
            maze[x, y].setVisited(true);
            foreach (Tuple<uint,uint> t in maze[x,y].getLinkedList())
            {
                if (maze[t.Item1, t.Item2].getVisited())
                    continue;
                if (maze[t.Item1, t.Item2].getType() == Type.END)
                    return true;
                bool goodPath = solveRec(t.Item1, t.Item2);
                if (goodPath)
                {
                    maze[t.Item1, t.Item2].isPath();
                    return true;
                }
            }
            return false;
        }
        #endregion



    }
}
