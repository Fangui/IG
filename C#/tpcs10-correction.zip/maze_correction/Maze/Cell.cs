﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Maze
{
    class Cell
    {

        private List<Tuple<uint, uint>> linked; //Contains the list of the position of the cells which are linked with this cell
        private Type type; //The type of the cell
        private bool visited; //Store if the cell was visited

        public Cell(Type type = Type.NONE)
        {
   
            linked = new List<Tuple<uint, uint>>();
            this.type = type;
            visited = false;

        }

        #region Initialization
        public Type getType()
        {
            return type;
        }

        public List<Tuple<uint, uint>> getLinkedList()
        {
            return linked;
        }


        public void setVisited(bool b)
        {
            visited = b;
        }

        public bool getVisited()
        {
            return visited;
        }
        #endregion


        #region Display
        public string display()
        {
            if (type == Type.NONE)
                return "  ";
            if (type == Type.START)
                return "SS";
            if (type == Type.PATH)
                return "XX";
            return "EE";
        }
        #endregion


        #region Generation
        public void addLink(Tuple<uint, uint> posToLink)
        {
            linked.Add(posToLink);
        }

        public bool isLinked(uint x, uint y)
        {
            foreach (Tuple<uint, uint> a in linked)
                if (a.Item1 == x && a.Item2 == y)
                    return true;
            return false;
        }
        #endregion

        #region Solve
        public void isPath()
        {
            if (type == Type.NONE)
                type = Type.PATH;
        }
        #endregion


    }
}
