﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyTinyToshop
{
    public static class Geometric
    {
        public static Image HorizontalMirror(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;

            for (int y = 0; y < h / 2; ++y)
            {
                for (int x = 0; x < w; ++x)
                {
                    Color tmp = img.GetPixel(x, y);
                    img.SetPixel(x, y, img.GetPixel(x, h - y - 1));
                    img.SetPixel(x, h - y - 1, tmp);
                }
            }

            return img;
        }

        public static Image VerticalMirror(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;

            for (int y = 0; y < h; ++y)
            {
                for (int x = 0; x < w / 2; ++x)
                {
                    Color tmp = img.GetPixel(x, y);

                    img.SetPixel(x, y, img.GetPixel(w - x - 1, y));
                    img.SetPixel(w - x - 1, y, tmp);
                }
            }

            return img;
        }

        public static Image LeftRotation(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            Bitmap res = new Bitmap(h, w);

            for (int y = 0; y < w; ++y)
            {
                for (int x = 0; x < h; ++x)
                    res.SetPixel(x, y, img.GetPixel(w - y - 1, x));
            }

            return res;
        }

        public static Image RightRotation(Bitmap img)
        {
            int w = img.Width;
            int h = img.Height;
            Bitmap res = new Bitmap(h, w);

            for (int y = 0; y < w; ++y)
            {
                for (int x = 0; x < h; ++x)
                    res.SetPixel(x, y, img.GetPixel(y, h - x - 1));
            }

            return res;
        }
    }
}
