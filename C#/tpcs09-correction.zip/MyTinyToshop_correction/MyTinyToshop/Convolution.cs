﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyTinyToshop
{
    public static class Convolution
    {
        public static float[,] AverageMask = { { 1/9f, 1/9f, 1/9f },
                                               { 1/9f, 1/9f, 1/9f }, 
                                               { 1/9f, 1/9f, 1/9f } };

        public static float[,] GaussMask = { { 1/16f, 2/16f, 1/16f },
                                             { 2/16f, 4/16f, 2/16f },
                                             { 1/16f, 2/16f, 1/16f } };

        public static float[,] SharpenMask = { {  0f, -1f, 0f  },
                                               { -1f,  5f, -1f },
                                               {  0f, -1f, 0f  } };

        public static float[,] EdgeEnhanceMask = { {  0f, 0f, 0f },
                                                   { -1f, 1f, 0f },
                                                   {  0f, 0f, 0f } };

        public static float[,] EdgeDetectMask = { { 0f,  1f, 0f },
                                                  { 1f, -4f, 1f },
                                                  { 0f,  1f, 0f } };

        public static float[,] EmbossMask = { { -2f, -1f, 0f },
                                              { -1f,  1f, 1f },
                                              {  0f,  1f, 2f } };


        private static int Clamp(float component)
        {
            return component < 0 ? 0 : (component > 255 ? 255 : (int)(component));
        }

        private static bool IsValid(int x, int y, Size size)
        {
            return x >= 0 && x < size.Width && y >= 0 && y < size.Height;
        }

        public static Image Convolute(Bitmap img, float[,] mask)
        {
            int offset = mask.GetLength(0) / 2;
            Bitmap res = new Bitmap(img);

            for (int y = 0; y < img.Size.Height; ++y)
            {
                for (int x = 0; x < img.Size.Width; ++x)
                {
                    float[] acc = { 0, 0, 0 };

                    for (int dy = -offset; dy <= offset; ++dy)
                    {
                        for (int dx = -offset; dx <= offset; ++dx)
                        {
                            if (IsValid(x + dx, y + dy, img.Size))
                            {
                                Color c = img.GetPixel(x + dx, y + dy);
                                float coef = mask[dy + offset, dx + offset];

                                acc[0] += c.R * coef;
                                acc[1] += c.G * coef;
                                acc[2] += c.B * coef;
                            }
                        }
                    }

                    res.SetPixel(x, y, Color.FromArgb(Clamp(acc[0]), Clamp(acc[1]), Clamp(acc[2])));
                }
            }

            return res;
        }
    }
}
