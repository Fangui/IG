﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyTinyToshop
{
    public static class ContrastStretch
    {

        public static Dictionary<char, int[]> GetHistogram(Bitmap img)
        {
            Dictionary<char, int[]> hist = new Dictionary<char, int[]> 
                                           { { 'R', new int[256] },
                                             { 'G', new int[256] },
                                             { 'B', new int[256] } };


            for (int y = 0; y < img.Height; ++y)
            {
                for (int x = 0; x < img.Width; ++x)
                {
                    Color c = img.GetPixel(x, y);
                    hist['R'][c.R]++;
                    hist['G'][c.G]++;
                    hist['B'][c.B]++;
                }
            }

            return hist;
        }

        private static int FindLow(int[] hist)
        {
            for (int i = 0; i < 256; ++i)
            {
                if (hist[i] != 0)
                    return i;
            }

            return 0;
        }

        private static int FindHigh(int[] hist)
        {
            for (int i = 255; i >= 0; --i)
            {
                if (hist[i] != 0)
                    return i;
            }

            return 255;
        }

        public static Dictionary<char, int>
        FindBound(Dictionary<char, int[]> hist, Func<int[], int> f)
        {
            Dictionary<char, int> bound = new Dictionary<char, int> 
                                          { { 'R', f(hist['R']) },
                                            { 'G', f(hist['G']) },
                                            { 'B', f(hist['B']) } };
            return bound;
        }


        public static int[] ComputeLUT(int low, int high)
        {
            int[] LUT = new int[256];

            for (int i = 0; i < low; ++i)
                LUT[i] = 0;

            float scale_factor = 255f / (high - low);

            for (int i = low; i <= high; ++i)
                LUT[i] = (int)((i - low) * scale_factor);

            for (int i = high + 1; i < 256; ++i)
                LUT[i] = 255;

            return LUT;
        }

        public static Dictionary<char, int[]> GetLUT(Bitmap img)
        {
            Dictionary<char, int[]> hist = GetHistogram(img);
            Dictionary<char, int> low = FindBound(hist, FindLow);
            Dictionary<char, int> high = FindBound(hist, FindHigh);

            Dictionary<char, int[]> LUT = new Dictionary<char, int[]> 
                                          { { 'R', ComputeLUT(low['R'], high['R']) },
                                            { 'G', ComputeLUT(low['G'], high['G']) },
                                            { 'B', ComputeLUT(low['B'], high['B']) } };

            return LUT;
        }

        public static Image ConstrastStretch(Bitmap img)
        {
            Dictionary<char, int[]> LUT = GetLUT(img);

            for (int y = 0; y < img.Size.Height; ++y)
            {
                for (int x = 0; x < img.Size.Width; ++x)
                {
                    Color color = img.GetPixel(x, y);

                    int red   = LUT['R'][color.R];
                    int green = LUT['G'][color.G];
                    int blue  = LUT['B'][color.B];

                    img.SetPixel(x, y, Color.FromArgb(255, red, green, blue));
                }
            }

            return img;
        }

    }
}
