﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace MyTinyToshop
{
    public static class Filters
    {
        public static Color Tint { get; set; }
        public static int Coef { get; set; }

        public static Bitmap MapPixels(Bitmap img, Func<Color, Color> filter,
                                       int xB, int yB, int xE, int yE)
        {
            for (int y = yB; y < yE; y++)
            {
                for (int x = xB; x < xE; x++)
                    img.SetPixel(x, y, filter(img.GetPixel(x, y)));
            }
            return img;
        }

        public static Bitmap MapPixels(Bitmap img, Func<Color, Color> filter)
        {
            return MapPixels(img, filter, 0, 0, img.Width, img.Height);
        }

        public static Color Greyscale(Color color)
        {
            int grey = (color.R + color.G + color.B) / 3;
            return Color.FromArgb(grey, grey, grey);
        }

        public static Color Negative(Color color)
        {
            int red = 255 - color.R;
            int green = 255 - color.G;
            int blue = 255 - color.B;
            return Color.FromArgb(red, green, blue);
        }

        public static Color Binarize(Color color)
        {
            Color grey = Greyscale(color);
            if (grey.R <= 127)
                return Color.Black;
            else
                return Color.White;
        }

        public static Color Tinter(Color color)
        {
            int red = (Tint.R - color.R) * Coef / 100 + color.R;
            int green = (Tint.G - color.G) * Coef / 100 + color.G;
            int blue = (Tint.B - color.B) * Coef / 100 + color.B;
            return Color.FromArgb(255, red, green, blue);
        }

        public static Image Stripes(Bitmap img, Color[] colors)
        {
            int w = img.Width;
            int h = img.Height;
            int nbStripes = colors.Length;

            for (int i = 0; i < nbStripes; ++i)
            {
                Tint = colors[i];
                img = MapPixels(img, Tinter, w * i / nbStripes, 0,
                                             w * (i + 1) / nbStripes, h);
            }

            return img;
        }
    }
}
