﻿namespace MoreOrLess
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_newGame = new System.Windows.Forms.Button();
            this.textBox_entry = new System.Windows.Forms.TextBox();
            this.button_validate = new System.Windows.Forms.Button();
            this.label_remaining = new System.Windows.Forms.Label();
            this.text_1 = new System.Windows.Forms.Label();
            this.textBox_max = new System.Windows.Forms.TextBox();
            this.richTextBox_history = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // button_newGame
            // 
            this.button_newGame.Location = new System.Drawing.Point(13, 13);
            this.button_newGame.Name = "button_newGame";
            this.button_newGame.Size = new System.Drawing.Size(113, 23);
            this.button_newGame.TabIndex = 0;
            this.button_newGame.Text = "Nouvelle Partie";
            this.button_newGame.UseVisualStyleBackColor = true;
            this.button_newGame.Click += new System.EventHandler(this.button_newGame_Click);
            // 
            // textBox_entry
            // 
            this.textBox_entry.Location = new System.Drawing.Point(154, 73);
            this.textBox_entry.Name = "textBox_entry";
            this.textBox_entry.Size = new System.Drawing.Size(100, 20);
            this.textBox_entry.TabIndex = 1;
            // 
            // button_validate
            // 
            this.button_validate.Enabled = false;
            this.button_validate.Location = new System.Drawing.Point(260, 71);
            this.button_validate.Name = "button_validate";
            this.button_validate.Size = new System.Drawing.Size(75, 23);
            this.button_validate.TabIndex = 2;
            this.button_validate.Text = "Valider";
            this.button_validate.UseVisualStyleBackColor = true;
            this.button_validate.Click += new System.EventHandler(this.button_validate_Click);
            // 
            // label_remaining
            // 
            this.label_remaining.AutoSize = true;
            this.label_remaining.Location = new System.Drawing.Point(12, 76);
            this.label_remaining.Name = "label_remaining";
            this.label_remaining.Size = new System.Drawing.Size(0, 13);
            this.label_remaining.TabIndex = 3;
            // 
            // text_1
            // 
            this.text_1.AutoSize = true;
            this.text_1.Location = new System.Drawing.Point(132, 18);
            this.text_1.Name = "text_1";
            this.text_1.Size = new System.Drawing.Size(170, 13);
            this.text_1.TabIndex = 5;
            this.text_1.Text = "Nombre mystère compris entre 1 et";
            // 
            // textBox_max
            // 
            this.textBox_max.Location = new System.Drawing.Point(308, 15);
            this.textBox_max.Name = "textBox_max";
            this.textBox_max.Size = new System.Drawing.Size(56, 20);
            this.textBox_max.TabIndex = 6;
            this.textBox_max.Text = "100";
            // 
            // richTextBox_history
            // 
            this.richTextBox_history.Location = new System.Drawing.Point(13, 119);
            this.richTextBox_history.Name = "richTextBox_history";
            this.richTextBox_history.Size = new System.Drawing.Size(351, 208);
            this.richTextBox_history.TabIndex = 7;
            this.richTextBox_history.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 349);
            this.Controls.Add(this.richTextBox_history);
            this.Controls.Add(this.textBox_max);
            this.Controls.Add(this.text_1);
            this.Controls.Add(this.label_remaining);
            this.Controls.Add(this.button_validate);
            this.Controls.Add(this.textBox_entry);
            this.Controls.Add(this.button_newGame);
            this.Name = "Form1";
            this.Text = "More Or Less";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_newGame;
        private System.Windows.Forms.TextBox textBox_entry;
        private System.Windows.Forms.Button button_validate;
        private System.Windows.Forms.Label label_remaining;
        private System.Windows.Forms.Label text_1;
        private System.Windows.Forms.TextBox textBox_max;
        private System.Windows.Forms.RichTextBox richTextBox_history;
    }
}

