﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MoreOrLess
{
    public partial class Form1 : Form
    {
        int number, nb_tries;
        Random rndm;

        public Form1()
        {
            InitializeComponent();
            rndm = new Random();
        }

        private void button_newGame_Click(object sender, EventArgs e)
        {
            number = rndm.Next(Convert.ToInt32(textBox_max.Text)) + 1;
            nb_tries = 10;
            label_remaining.Text = "Coups restants: " + nb_tries;
            button_validate.Enabled = true;
            richTextBox_history.Text = "";
        }

        private void button_validate_Click(object sender, EventArgs e)
        {
            nb_tries--;
            richTextBox_history.Text += "Dernier essai: " + Convert.ToInt32(textBox_entry.Text) + ". ";
            if (nb_tries < 1 && Convert.ToInt32(textBox_entry.Text) != number)
            {
                richTextBox_history.Text += "Perdu ! Le nombre mystère était " + number;
                button_validate.Enabled = false;
            }
            else
            {
                label_remaining.Text = "Coups restants: " + nb_tries;
                if (Convert.ToInt32(textBox_entry.Text) == number)
                {
                    richTextBox_history.Text += "Gagné !";
                    button_validate.Enabled = false;
                }
                else if (Convert.ToInt32(textBox_entry.Text) < number)
                {
                    richTextBox_history.Text += "C'est plus !\n";
                }
                else if (Convert.ToInt32(textBox_entry.Text) > number)
                {
                    richTextBox_history.Text += "C'est moins !\n";
                }
            }
        }
    }
}
