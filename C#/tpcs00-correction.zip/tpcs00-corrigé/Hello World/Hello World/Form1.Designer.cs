﻿namespace Hello_World
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_say = new System.Windows.Forms.Button();
            this.label_say = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_say
            // 
            this.button_say.Location = new System.Drawing.Point(13, 13);
            this.button_say.Name = "button_say";
            this.button_say.Size = new System.Drawing.Size(75, 23);
            this.button_say.TabIndex = 0;
            this.button_say.Text = "Say";
            this.button_say.UseVisualStyleBackColor = true;
            this.button_say.Click += new System.EventHandler(this.button_say_Click);
            // 
            // label_say
            // 
            this.label_say.AutoSize = true;
            this.label_say.Location = new System.Drawing.Point(114, 18);
            this.label_say.Name = "label_say";
            this.label_say.Size = new System.Drawing.Size(0, 13);
            this.label_say.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 49);
            this.Controls.Add(this.label_say);
            this.Controls.Add(this.button_say);
            this.Name = "Form1";
            this.Text = "Hello World";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_say;
        private System.Windows.Forms.Label label_say;
    }
}

