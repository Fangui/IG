﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Raytracer.utils
{
    class Polynomial
    {
        #region Attributes
        private double[] coefs_;
        private uint n_;
        #endregion

        #region Constructor
        public Polynomial(double[] coefs, uint n)
        {
            this.n_ = n;
            this.coefs_ = new double[n + 1];
            coefs.CopyTo(this.coefs_, 0);
        }
        #endregion  

        #region Methods
        /// <summary>
        /// Solves a second degree polynomial equation
        /// </summary>
        /// <param name="squares">The array representing the different coefficients</param>
        /// <returns>1 if the solution is unique, 2 if the equation has two roots, 0 otherwise</returns>
        public uint resolve_quadratic(ref double[] squares)
        {
            double delta = coefs_[1] * coefs_[1] - 4 * coefs_[0] * coefs_[2];

            if (delta < 0)
                return 0;
            else if (delta == 0)
            {
                squares = new double[1];
                squares[0] = -coefs_[1] / (2 * coefs_[0]);
                return 1;
            }
            else
            {
                squares = new double[2];
                squares[0] = (-coefs_[1] + Math.Sqrt(delta)) / (2 * coefs_[0]);
                squares[1] = (-coefs_[1] - Math.Sqrt(delta)) / (2 * coefs_[0]);
                return 2;
            }
        }

        /// <summary>
        /// Solves a third degree polynomial equation
        /// </summary>
        /// <param name="squares">The array representing the different coefficients</param>
        /// <returns>1 if the solution is unique, 3 if the equation has three roots</returns>
        public uint resolve_cubic(ref double[] squares)
        {
            double q, r, D, Dprime, t, s;
            double a = coefs_[0];
            double b = coefs_[1];
            double c = coefs_[2];
            double d = coefs_[3];

            b = b / a;
            c = c / a;
            d = d / a;

            q = (b * b - 3 * c) / 9.0d;
            r = (b * (b * b - 4.5d * c) + 13.5d * d) / 27.0d;
            D = q * q * q - r * r;

            if (D >= 0)
            {
                Dprime = r / Math.Exp((3.0d / 2.0d) * Math.Log(q));
                t = Math.Acos(Dprime) / 3;
                s = -2 * Math.Sqrt(q);

                for (int i = 0; i < 3; ++i)
                    squares[i] = s * Math.Cos(t + 2 * Math.PI * (i / 3.0d)) - b / 3.0d;

                return 3;
            }

            else
            {
                s = Math.Exp((1.0d / 3.0d) * Math.Log(Math.Sqrt(-D) + Math.Abs(r)));

                if (r < 0)
                    squares[0] = s + q / s - b / 3.0d;
                else
                   squares[0] = -s - q / s - b / 3.0d;

                return 1;
            }
        }
        #endregion
    }
}
