﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Raytracer.utils;

namespace Raytracer.lights
{
    class SpotLight : AttenuationLight
    {
        private Vector3 dir_;
        private float outer_cut_off_;
        private float cut_off_;

        public SpotLight(NormalizedColor c, Vector3 pos, Vector3 dir,
                         float cut_off = 0.984f, float outer_cut_off = 0.965f,
                         float cst = 0, float linear = 0, float quadratic = 0)
                         : base(c, pos, cst, linear, quadratic)
        {
            this.dir_ = dir;
            this.cut_off_ = cut_off;
            this.outer_cut_off_ = outer_cut_off;

            dir.normalize();
        }

        public override NormalizedColor apply_lightning(NormalizedColor ambient, Material material,
                                                        Ray ray, Vector3 normal, Vector3 point)
        {
            // Diffuse
            NormalizedColor diffuse;
            Vector3 to_point = pos_ - point;
            to_point.normalize();

            float intensity = ((float)((dir_ * -1) | to_point) - outer_cut_off_)
                              / (cut_off_ - outer_cut_off_);
            intensity = (intensity < 0.0f) ? 0.0f : intensity;
            intensity = (intensity > 1.0f) ? 1.0f : intensity;

            diffuse = color_ * Math.Max((dir_ * -1) | normal, 0.0d);

            // Specular
            double spec_factor = specular_get(ray, dir_, point, normal, material.shininess);
            NormalizedColor specular_color = material.specular * spec_factor * color_;

            // Light attenuation
            double attenuation = attenuation_get(point);

            ambient = ambient * attenuation * intensity;
            diffuse = diffuse * attenuation * intensity;
            specular_color = specular_color * attenuation * intensity;

            return (diffuse + specular_color) * material.diffuse * ambient;
        }

        public override Vector3 get_direction(Vector3 point)
        {
            return dir_;
        }
    }
}
