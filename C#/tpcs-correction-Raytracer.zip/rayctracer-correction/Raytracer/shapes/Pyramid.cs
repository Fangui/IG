﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Raytracer.utils;

namespace Raytracer.shapes
{
    class Pyramid : Shape
    {
        private PyramidFace[] triangle_faces_;
        private PyramidFace   inter_face_;
        private CubeFace      base_face_;

        public Pyramid(Material mat, Vector3 pos, float base_size, float height) : base(mat)
        {
            base_face_ = new CubeFace(mat, new Vector3(pos.X + base_size / 2, pos.Y, pos.Z - base_size / 2),
                                           new Vector3(pos.X - base_size / 2, pos.Y, pos.Z - base_size / 2),
                                           new Vector3(pos.X + base_size / 2, pos.Y, pos.Z + base_size / 2));

            triangle_faces_ = new PyramidFace[4];

            triangle_faces_[0] = new PyramidFace(mat, new Vector3(pos.X + base_size / 2, pos.Y, pos.Z - base_size / 2),
                                                      new Vector3(pos.X, pos.Y + height, pos.Z),
                                                      new Vector3(pos.X - base_size / 2, pos.Y, pos.Z - base_size / 2));
            triangle_faces_[1] = new PyramidFace(mat, new Vector3(pos.X + base_size / 2, pos.Y, pos.Z + base_size / 2),
                                                      new Vector3(pos.X, pos.Y + height, pos.Z),
                                                      new Vector3(pos.X + base_size / 2, pos.Y, pos.Z - base_size / 2));
            triangle_faces_[2] = new PyramidFace(mat, new Vector3(pos.X - base_size / 2, pos.Y, pos.Z + base_size / 2),
                                                      new Vector3(pos.X, pos.Y + height, pos.Z),
                                                      new Vector3(pos.X + base_size / 2, pos.Y, pos.Z + base_size / 2));
            triangle_faces_[3] = new PyramidFace(mat, new Vector3(pos.X - base_size / 2, pos.Y, pos.Z - base_size / 2),
                                                      new Vector3(pos.X, pos.Y + height, pos.Z),
                                                      new Vector3(pos.X - base_size / 2, pos.Y, pos.Z + base_size / 2));
        }

        public override Vector3 intersect(Ray ray)
        {
            Vector3 min = null;
            Vector3 cur = null;

            foreach (PyramidFace cf in triangle_faces_)
            {
                cur = cf.intersect(ray);
                if (cur != null && (min == null || cur.norm() < min.norm()))
                {
                    min = cur;
                    inter_face_ = cf;
                }
            }

            return min;
        }

        public override Vector3 normal_at_point(Vector3 point)
        {
            return inter_face_.normal_at_point(point);
        }
    }
}
