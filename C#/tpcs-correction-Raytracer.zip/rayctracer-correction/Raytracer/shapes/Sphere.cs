﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

using Raytracer.utils;

namespace Raytracer.shapes
{
    class Sphere : Shape
    {
        #region Attributes
        private float radius_;
        private Vector3 pos_;
        #endregion

        #region Constructor
        public Sphere(Material mat, Vector3 position, float radius) : base(mat)
        {
            pos_ = position;
            radius_ = radius;
        }
        #endregion

        #region Methods
        public override Vector3 intersect(Ray ray)
        {
            double a = ray.Dir | ray.Dir;
            double b = 2 * (ray.Dir | (ray.Origin - pos_));
            double c = ((ray.Origin - pos_) | (ray.Origin - pos_)) - (radius_ * radius_);

            double[] squares = new double[2];
            double[] coefs = { a, b, c };

            Polynomial p = new Polynomial(coefs, 2);
            uint result = p.resolve_quadratic(ref squares);

            if (result == 1 && squares[0] >= 0)
                return ray.Origin + ray.Dir * squares[0];
            else if (result == 2)
            {
                double min = Math.Min(squares[0], squares[1]);

                if (min < 0)
                {
                    double max = Math.Max(squares[0], squares[1]);
                    if (max > 0)
                        return ray.Origin + ray.Dir * max;
                    else
                        return null;
                }

                return ray.Origin + ray.Dir * min;
            }
            else
                return null;
        }

        public override Vector3 normal_at_point(Vector3 point)
        {
            Vector3 normal = point - pos_;
            normal.normalize();
            return normal;
        }
        #endregion
    }
}
