﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Raytracer.utils;

namespace Raytracer.shapes
{
    class CubeFace : Shape
    {
        private Vector3 point_a_;
        private Vector3 point_b_;
        private Vector3 point_c_;

        public CubeFace(Material mat ,Vector3 point_a, Vector3 point_b, Vector3 point_c) : base(mat)
        {
            point_a_ = point_a;
            point_b_ = point_b;
            point_c_ = point_c;
        }

        public override Vector3 intersect(Ray ray)
        {
            Vector3 u = point_b_ - point_a_;
            Vector3 v = point_c_ - point_a_;
            Vector3 w = ray.Origin - point_a_;

            double a = ((w * v) | ray.Dir) / ((u * v) | ray.Dir);
            double b = ((u * w) | ray.Dir) / ((u * v) | ray.Dir);

            if (a >= 0 && b >= 0 && a <= 1 && b <= 1)
                return ray.Origin + ray.Dir * (-((u * v) | w) / ((u * v) | ray.Dir));
            else
                return null;
        }

        public override Vector3 normal_at_point(Vector3 point)
        {
            Vector3 u = point_b_ - point_a_;
            Vector3 v = point_c_ - point_a_;
            Vector3 normal = u * v;
            normal.normalize();

            return normal;
        }
    }
}
