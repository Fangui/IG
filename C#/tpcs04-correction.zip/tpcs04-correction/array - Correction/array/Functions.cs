﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace array
{
    class Functions
    {
        static int count_words(char[] str)
        {

            int nb_words = 0;
            int i = 0;
            while (i < str.Length && str[i] == ' ')
                i++;
            while (i < str.Length)
            {
                if (str[i] == ' ')
                {
                    nb_words++;
                    while (i < str.Length && str[i] == ' ')
                        i++;
                }
                else
                {
                    i++;
                }
            }
            if (str[str.Length - 1] != ' ')
                nb_words++;
            return nb_words;
        }
        static void real_length(char[] str, ref int length)
        {
            while (length > 0 && str[length - 1] == ' ')
            {
                length--;
            }
        }
        static char[] substring(char[] str, int start, int end)
        {
            char[] res = new char[end - start];
            for (int i = 0; start + i < str.Length && start + i < end; i++)
            {
                res[i] = str[i + start];
            }
            return res;
        }

        static char[] get_next_word(char[] str, ref int start)
        {
            while (start < str.Length && str[start] == ' ')
                start++;
            int begin = start;
            if (start == str.Length)
                return new char[0];
            while (start < str.Length && str[start] != ' ')
                start++;
            return substring(str, begin, start);
        }

        static char[][] split_string(char[] str)
        {
            int length = str.Length;
            real_length(str, ref length);
            int c = count_words(str);
            char[][] tab = new char[c][];
            int start = 0;
            for (int i = 0; i < c; i++)
            {
                tab[i] = get_next_word(str, ref start);
            }
            return tab;
        }
        static void print_array(char[][] tab)
        {
            for (int i = 0; i < tab.Length - 1; i++)
            {
                for (int j = 0; j < tab[i].Length; j++)
                {
                    Console.Write(tab[i][j]);
                }
                Console.Write(",");
            }
            for (int j = 0; j < tab[tab.Length - 1].Length; j++)
            {
                Console.Write(tab[tab.Length - 1][j]);
            }

        }

        static Functions()
        {
            int length = 11;
            char[] a = { 'H', 'e', 'l', 'l', 'o', ' ', ' ', ' ', ' ', ' ', ' ' };
            real_length(a, ref length);
            char[] s = substring(a, 1, 4);
            int start = 5;
            char[] c = { 'H', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd', ' ' };
            s = get_next_word(c, ref start);
            char[] b = { 'H', 'e', 'l', 'l', 'o', ' ', ' ', ' ', 'h', 'o', 'w', ' ', 'a', 'r', 'e', ' ', 'y', 'o', 'u' };
            Console.WriteLine(count_words(a));
            Console.WriteLine(count_words(b));
            int l = 5;
            Console.WriteLine(get_next_word(b, ref l));
            char[][] tab = split_string(b);
            print_array(split_string(b));
            Console.Read();
        }
    }
}
