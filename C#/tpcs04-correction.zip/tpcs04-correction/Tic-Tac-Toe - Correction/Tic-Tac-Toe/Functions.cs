﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tic_Tac_Toe
{
    class Functions
    {
        static void print_matrix(int[][] array)
        {
            Console.Write(" ");
            for (int j = 0; j < array[0].Length; j++)
                Console.Write("__");
            Console.WriteLine("_");
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(" ");
                for (int j = 0; j < array[i].Length; j++)
                {
                    switch (array[i][j])
                    {
                        case 0:
                            Console.Write("| ");
                            break;
                        case 1:
                            Console.Write("|o");
                            break;
                        case 2:
                            Console.Write("|x");
                            break;
                        default:
                            Console.Write("|?");
                            break;
                    }
                }
                Console.WriteLine("|");
                if (i != array[0].Length - 1)
                {

                    Console.Write(" |-");
                    for (int j = 1; j < array[0].Length; j++)
                        Console.Write("--");
                    Console.WriteLine("|");
                }

            }
            Console.Write(" ");
            for (int j = 0; j < array[0].Length; j++)
                Console.Write("--");
            Console.WriteLine("-");
        }
        static int[][] init_matrix(int n)
        {
            int[][] matrix = new int[n][];
            for (int i = 0; i < n; i++)
            {
                matrix[i] = new int[n];
                for (int j = 0; j < n; j++)
                {
                    matrix[i][j] = 0;
                }
            }
            return matrix;
        }

        static int play(int player, int x, int y, ref int[][] matrix)
        {

            if (x >= matrix.Length || y >= matrix.Length)
            {
                Console.WriteLine("invalid index");
                return 0;
            }
            if (player != 1 && player != 2)
            {
                Console.WriteLine("invalid number for a player");
                return 0;
            }
            if (matrix[x][y] != 0)
            {
                Console.WriteLine("already played");
                return 0;
            }
            matrix[x][y] = player;
            return 1;
        }


        static bool check_columns(int[][] matrix)
        {
            int player;

            int j;
            for (int i = 0; i < matrix.Length; i++)
            {
                player = matrix[0][i];
                j = 1;
                while (player != 0 && j < matrix.Length && matrix[j][i] == player)
                    j++;
                if (j == matrix.Length)
                    return true;
            }
            return false;
        }

        static bool check_rows(int[][] matrix)
        {
            int player;
            int j;
            for (int i = 0; i < matrix.Length; i++)
            {
                player = matrix[i][0];
                j = 1;
                while (player != 0 && j < matrix.Length && matrix[i][j] == player)
                    j++;
                if (j == matrix.Length)
                    return true;
            }
            return false;
        }

        static bool check_diagonals(int[][] matrix)
        {
            int player = matrix[0][0];
            if (player == 0)
                return false;
            int i = 0;
            while (i < matrix.Length && matrix[i][i] == player)
                i++;
            if (i == matrix.Length)
                return true;
            player = matrix[0][matrix.Length - 1];
            if (player == 0)
                return false;
            i = 0;
            while (i < matrix.Length && matrix[i][matrix.Length - i - 1] == player)
                i++;
            if (i == matrix.Length)
                return true;
            return false;
        }



        static bool check_win(int[][] matrix)
        {
            return check_rows(matrix) || check_columns(matrix) || check_diagonals(matrix);
        }


        static bool check_end(int[][] matrix)
        {
            bool end = true;
            for (int i = 0; i < matrix.Length && end; i++)
            {
                for (int j = 0; j < matrix.Length && end; j++)
                {
                    end = !(matrix[i][j] == 0);
                }
            }
            return end;
        }

        static void game(int n)
        {
            int[][] m = init_matrix(n);
            int player = 1;
            while (!check_end(m))
            {
                try
                {
                    Console.WriteLine(player);
                    Console.Write("x:");
                    int x = Convert.ToInt32(Console.ReadLine()) - 1;
                    if (x < 0 || x >= m.Length)
                        throw new Exception(" wgfgsd");

                    Console.Write("y:");
                    int y = Convert.ToInt32(Console.ReadLine()) - 1;
                    if (x < 0 || x >= m.Length)
                        throw new Exception("");
                    if (1 == play(player, x, y, ref m))
                        player = 3 - player;
                    print_matrix(m);
                    if (check_win(m))
                    {
                        Console.WriteLine(3 - player + "won");
                        break;
                    }

                }
                catch (Exception)
                {
                    Console.WriteLine("Need a number between 1 and " + m.Length);

                }

            }
        }

        static Functions()
        {
            game(3);
            Console.ReadKey();

        }
    }
}

