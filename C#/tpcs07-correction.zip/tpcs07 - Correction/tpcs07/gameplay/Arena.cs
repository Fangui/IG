﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tpcs07
{
    public class Arena
    {
        Pokemon mine_, opponent_, attacking_, undergoing_;
        public Arena(Pokemon left, Pokemon right)
        {
            this.mine_ = left;
            this.opponent_ = right;
            attacking_ = left;
            undergoing_ = right;
        }

        public void change_attacker()
        {
            Pokemon swap;
            swap = attacking_;
            attacking_ = undergoing_;
            undergoing_ = swap;
        }

        public void attack_with(int n)
        {
            undergoing_.undergo(attacking_.get_attack(n));
        }

        public bool is_finished()
        {
			return (!mine_.is_alive() || !opponent_.is_alive());
        }

        #region
        public Pokemon left
        {
            get { return mine_; }
            set { mine_ = value; }
        }

        public Pokemon right
        {
            get { return opponent_; }
            set { opponent_ = value; }
        }
        #endregion
    }
}
