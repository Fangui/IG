﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tpcs07
{
    public class Attack
    {
        static Random   rand_ = new Random();

        private string  name_;
        private int     min_damage_;
        private int     max_damage_;

        private int     critical_rate_;
        private int     critical_fail_rate_;
        private int     critical_bonus_rate_;

        public Attack(string name, int min, int max, int crit_rate,
                      int crit_fail_rate, int crit_bonus_rate)
        {
            this.name_ = name;
            this.min_damage_ = min;
            this.max_damage_ = max;
            this.critical_rate_ = crit_rate;
            this.critical_fail_rate_ = crit_fail_rate;
            this.critical_bonus_rate_ = crit_bonus_rate;
        }

        public int damage_get()
        {
            int critical = rand_.Next(0, 100);
            if (critical < critical_fail_rate_)
                return min_damage_;

            int normal_damage = rand_.Next(min_damage_, max_damage_);
            if (critical > critical_rate_)
                return normal_damage + (normal_damage * critical_bonus_rate_ / 100);
            return normal_damage;
        }

        public string Name { get { return name_; } }
    }
}
