﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tpcs07
{
    public class Pokemon
    {
        private string  name_;
        private int     pv_;
        private int     pv_max_;
        private int     lvl_;

        private Attack[] attack_tab_;
        private PokemonType type_;

        public Pokemon(string name, PokemonType type, int lvl, int PV)
        {
            this.name_ = name;
            this.type_ = type;
            this.pv_ = PV;
            this.lvl_ = lvl;
            this.pv_max_ = pv;

            this.attack_tab_ = new Attack[2];
        }

        public string who_am_i()
        {
            if (lvl_ < 10)
                return "My name is " + name + " and I am quite weak."; 
            else if (lvl_ < 25)
                return "My name is " + name + " and I am still under training.";
            else if (lvl_ < 50)
                return "My name is " + name + " and I am ready to battle.";
            else if (lvl_ < 75)
                return "My name is " + name + " and I am quite strong.";
            else
                return "My name is " + name + " and you can not beat me.";
        }

        public void undergo(Attack a)
        {
            int damage = a.damage_get();
            if (damage > pv)
                pv = 0;
            else
                pv -= damage;
        }

        #region Gets/Set
        public string name
        {
            get { return name_; }
            set { name_ = value; }
        }

        public PokemonType type
        {
            get { return type_; }
        }

        public int pv
        {
            get { return pv_; }
            set { pv_ = value; }
        }

        public int pv_max
        {
            get { return pv_max_; }
            set { pv_max_ = value; }
        }

        public int lvl
        {
            get { return lvl_; }
            set { lvl_ = value; }
        }

        public void set_attack(Attack new_attack, int n)
        {
            this.attack_tab_[n] = new_attack;
        }

        public Attack get_attack(int n)
        {
            return this.attack_tab_[n];
        }

        public bool is_alive()
        {
            return (pv > 0);
        }
        #endregion
    }

    public enum PokemonType
    {
        Pikachu,
        Dracaufeu,
        Lockhlass,
        Smogogo,
        Spectrum,
        Aquali
    };
}