﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tpcs07
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

#if POKEMON
            // Create both pokemon here
            Pokemon left = new Pokemon("Davidchu", PokemonType.Pikachu ,10, 100);
            left.set_attack(new Attack("caca", 0, 35, 12, 14, 5), 0);
            left.set_attack(new Attack("caca2", 0, 35, 12, 14, 5), 1);
            Pokemon right = new Pokemon("Stanchu", PokemonType.Pikachu, 1, 20);
            right.set_attack(new Attack("caca-stan", 0, 35, 12, 14, 5), 0);
            right.set_attack(new Attack("caca-stan2", 0, 35, 12, 14, 5), 1);
            // Set two attacks for each pokemon

            // Create an Arena with the two pokemon
            Arena arena = new Arena(left, right);
            Application.Run(new Form1(arena));
#else
            Application.Run(new Form1());
#endif
        }
    }
}
