﻿using System;

namespace mySimCity
{
    internal class House
    {
        public House(int rooms)
        {
            Rooms = rooms;
        }

        public int Rooms { get; }

        public virtual void WhoAmI()
        {
            Console.WriteLine("Je suis une maison !");
        }

        public virtual void Describe()
        {
            Console.WriteLine("Maison de {0} pièces.", Rooms);
        }
    }
}