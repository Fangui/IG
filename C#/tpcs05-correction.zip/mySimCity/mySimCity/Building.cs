﻿using System;

namespace mySimCity
{
    internal class Building : House
    {
        public Building(int rooms, int floors) : base(rooms)
        {
            Floors = floors;
        }

        public int Floors { get; }

        public override void WhoAmI()
        {
            Console.WriteLine("Je suis un immeuble.");
        }

        public override void Describe()
        {
            Console.WriteLine("Immeuble de {0} étages de {1} pièces.", Floors, Rooms);
        }
    }
}