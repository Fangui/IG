﻿using System;

namespace mySimCity
{
    internal class Tree : House
    {
        public Tree() : base(0)
        {
        }

        public override void WhoAmI()
        {
            Console.WriteLine("Je suis un arbre (binaire ?)");
        }

        public override void Describe()
        {
            Console.WriteLine("Je suis un aaaarrbree!!!");
        }
    }
}