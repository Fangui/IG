﻿using System;

namespace mySimCity
{
    internal class Female : Human
    {
        public Female(string name, int age) : base(name, age)
        {
        }

        public override void WhoAmI()
        {
            Console.WriteLine("Je suis une femme");
        }

        public override void Describe()
        {
            Console.WriteLine("{0}, {1} ans (femme).", Name, Age);
        }
    }
}