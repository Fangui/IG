﻿using System;

namespace mySimCity
{
    internal class Male : Human
    {
        public Male(string name, int age) : base(name, age)
        {
        }

        public override void WhoAmI()
        {
            Console.WriteLine("Je suis un homme (#zazi)");
        }

        public override void Describe()
        {
            Console.WriteLine("{0}, {1} ans (homme).", Name, Age);
        }
    }
}