﻿using System;

namespace mySimCity
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("=========== Level 1 =========");
            var paris = new City("Paris");
            paris.AddHuman(new Human("Michel", 26));
            paris.AddHuman(new Human("Thomas", 21));
            paris.AddHouse(new House(5));
            paris.Describe();

            Console.WriteLine("=========== Level 2 =========");
            paris = new City("Paris");
            paris.AddHuman(new Male("Michel", 26));
            paris.AddHuman(new Female("Isabelle", 21));
            paris.AddHouse(new Building(3, 5));
            paris.AddHouse(new Tree());
            var h = new House(2);
            paris.AddHouse(h);
            paris.DestroyHouse(h);
            paris.Describe();
            Console.ReadLine();
        }
    }
}