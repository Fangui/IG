﻿using System;

namespace mySimCity
{
    internal class Human
    {
        public Human(string name, int age)
        {
            Age = age;
            Name = name;
        }

        public int Age { get; private set; }
        public string Name { get; }

        public virtual void WhoAmI()
        {
            Console.WriteLine("Je suis un humain !");
        }

        public void BirthDay()
        {
            ++Age;
        }

        public virtual void Describe()
        {
            Console.WriteLine("{0}, {1} ans.", Name, Age);
        }
    }
}