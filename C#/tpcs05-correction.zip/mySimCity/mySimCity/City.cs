﻿using System;
using System.Collections.Generic;

namespace mySimCity
{
    internal class City
    {
        private readonly List<Human> m_gens;

        private readonly List<House> m_maisons;

        public City(string name)
        {
            Name = name;
            m_maisons = new List<House>();
            m_gens = new List<Human>();
        }

        public string Name { get; }

        public void WhoAmI()
        {
            Console.WriteLine("Je suis une ville.");
        }

        public void AddHuman(Human h)
        {
            m_gens.Add(h);
        }

        public void AddHouse(House h)
        {
            m_maisons.Add(h);
        }

        public void KillHuman(Human h)
        {
            m_gens.Remove(h);
        }

        public void DestroyHouse(House h)
        {
            m_maisons.Remove(h);
        }

        public void Describe()
        {
            Console.WriteLine("Ville de {0}", Name);
            Console.WriteLine("{0} habitant{1}:", m_gens.Count, m_gens.Count > 1 ? "s " : " ");
            foreach (var human in m_gens)
            {
                Console.Write("* ");
                human.Describe();
            }
            Console.WriteLine("{0} maison{1}:", m_maisons.Count, m_maisons.Count > 1 ? "s " : " ");
            foreach (var house in m_maisons)
            {
                Console.Write("* ");
                house.Describe();
            }
        }
    }
}