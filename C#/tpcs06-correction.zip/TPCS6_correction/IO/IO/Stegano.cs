﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class Stegano
    {
        private static int get_bit(byte b, int index)
        {
            if (index > 7)
                return 0;
            return (b & (1 << (7 - index))) >> (7 - index);
        }

        private static System.Drawing.Color encode_component(int state, System.Drawing.Color base_color, int prim_component)
        {
            int red = base_color.R;
            int green = base_color.G;
            int blue = base_color.B;
            if (prim_component == 0)
                red = red / 2 * 2 + state;
            else if (prim_component == 1)
                green = green / 2 * 2 + state;
            else
                blue = blue / 2 * 2 + state;
            return System.Drawing.Color.FromArgb(base_color.A, red, green, blue);
        }

        private static void set_next_coords(ref int x, ref int y, System.Drawing.Bitmap image)
        {
            x++;
            if (x == image.Width)
            {
                x = 0;
                y++;
            }
        }

        public static void hide(string path, string text)
        {
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(path);
            text += '\0';
            int x = 0;
            int y = 0;

            foreach (byte c in text)
            {
                byte c2 = c;
                for (int n_bit = 0; n_bit < 9; n_bit++)
                {
                    System.Drawing.Color color = bmp.GetPixel(x, y);
                    bmp.SetPixel(x, y, encode_component(get_bit(c2, n_bit), color, n_bit % 3));
                    Console.WriteLine(x + ", " + y + ": " + get_bit(c2, n_bit) + ", " + n_bit);
                    if (n_bit % 3 == 2)
                        set_next_coords(ref x, ref y, bmp);
                }
            }
            bmp.Save(path + "_out.bmp");
        }

        public static string reveal(string path)
        {
            string result = "";
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(path);
            byte c = 0;
            int bit_counter = 0;

            for (int y = 0; y < bmp.Height; y++)
            {
                for (int x = 0; x < bmp.Width; x++)
                {
                    for (int prim_component = 0; prim_component < 3; prim_component++)
                    {
                        if (prim_component == 0)
                            c = (byte)(2 * c + bmp.GetPixel(x, y).R % 2);
                        else if (prim_component == 1)
                            c = (byte)(2 * c + bmp.GetPixel(x, y).G % 2);
                        else
                            c = (byte)(2 * c + bmp.GetPixel(x, y).B % 2);
                        bit_counter++;
                        if (bit_counter == 8)
                        {
                            result += (char)c;
                            bit_counter = 0;
                            prim_component = 3;
                            if (c == 0)
                                return result;
                        }
                    }
                }
            }
            return result;
        }
    }
}
