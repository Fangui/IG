﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class Splitter
    {
        public static void split(string input_path, string dir_path, int nb)
        {
            System.IO.FileStream inf = new System.IO.FileStream(input_path, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader reader = new System.IO.BinaryReader(inf);
            System.IO.BinaryWriter[] writers = new System.IO.BinaryWriter[nb];
            for (int x = 0; x < nb; x++)
                writers[x] = new System.IO.BinaryWriter(new System.IO.FileStream(dir_path + "/part_" + (x + 1) + ".ACDC",
                                                                 System.IO.FileMode.Create,
                                                                 System.IO.FileAccess.Write));

            int index = 0;
            while (reader.PeekChar() != -1)
            {
                writers[index].Write(reader.ReadChar());
                index = (index + 1) % nb;
            }
            foreach (System.IO.BinaryWriter wd in writers)
                wd.Close();
            reader.Close();
        }

        public static void merge(string output_path, string dir_path, int nb)
        {
            System.IO.FileStream inf = new System.IO.FileStream(output_path, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            System.IO.BinaryWriter writer = new System.IO.BinaryWriter(inf);
            System.IO.BinaryReader[] readers = new System.IO.BinaryReader[nb];
            for (int x = 0; x < nb; x++)
                readers[x] = new System.IO.BinaryReader(new System.IO.FileStream(dir_path + "/part_" + (x + 1) + ".ACDC",
                                                                 System.IO.FileMode.Open,
                                                                 System.IO.FileAccess.Read));
            int index = 0;
            while ((readers[index]).PeekChar() != -1)
            {
                writer.Write(readers[index].ReadChar());
                index = (index + 1) % nb;
            }
            foreach (System.IO.BinaryReader rd in readers)
                rd.Close();
            writer.Close();
        }
    }
}
