﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IO
{
    class Strings
    {
        static bool is_printable(char c)
        {
            return c >= ' ' && c <= '~';
        }
        public static string strings(string path)
        {
            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader br = new System.IO.BinaryReader(fs);
            string result = "";
            string current_sub_string = "";
            while (br.PeekChar() != -1)
            {
                char c = br.ReadChar();
                if (is_printable(c))
                    current_sub_string += c;
                else
                {
                    if (current_sub_string.Length >= 4)
                        result += current_sub_string + "\n";
                    current_sub_string = "";
                }
            }
            return result;
        }
    }
}
