﻿using System.Windows;

namespace Client
{
    /// <summary>
    ///     Logique d'interaction pour Transfert.xaml
    /// </summary>
    public partial class Transfert : Window
    {
        public Transfert()
        {
            InitializeComponent();
        }
    }
}