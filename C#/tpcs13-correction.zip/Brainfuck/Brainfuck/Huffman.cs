﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Brainfuck
{
    public class HuffmanCode
    {
        public string program;
        public string huffman_program;
        private Dictionary<char, string> encodings = new Dictionary<char, string>();

        public HuffmanCode(string program)
        {
            this.program = program;
            generate_huffman_code(program);
            huffman_program = get_huffman_from_brainfuck();
        }

        public void print_code()
        {
            foreach (KeyValuePair<char, string> s in encodings)
            {
                Console.WriteLine("Key " + s.Key + " : " + s.Value);
            }
        }

        public string get_huffman_from_brainfuck()
        {
            string p = "";
            string comp = "";
            comp += '<' + encodings['<']
                 + '>' + encodings['>']
                 + '+' + encodings['+']
                 + '-' + encodings['-']
                 + '.' + encodings['.']
                 + ',' + encodings[',']
                 + '[' + encodings['[']
                 + ']' + encodings[']']
                 + 'E'+ encodings['E'] + '\n';
            string target = program + 'E';
            foreach (char c in target)
            {
                p += encodings[c];
                if (p.Length >= 8)
                {
                    comp += (char)Convert.ToInt64(p.Substring(0, 8),2);
                    p = p.Remove(0, 8);
                }
            }
            if (p != "")
            {
                while (p.Length < 8)
                    p += '0';
                comp += (char)Convert.ToInt64(p,2);
            }
            return comp;
        }

        public static string get_brainfuck_from_huffman(string huffman_program_)
        {
            string p = "";
            string decomp = "";
            string new_prog = "";
            Dictionary<char, string> code = new Dictionary<char, string>();
            bool prefix = true;
            char? currchar = null;
            string currval  = "";
            foreach (char c in huffman_program_)
            {
                if (prefix)
                {
                    if (c != '0' && c != '1' && c != '\n')
                    {
                        if (currchar != null)
                            code.Add((char)currchar, currval);
                        currchar = c;
                        currval = "";
                    }
                    else if (c == '\n')
                    {
                        code.Add((char)currchar, currval);
                        prefix = false;
                    }
                    else
                        currval += c;
                }
                else
                {
                    string tmp = Convert.ToString(c, 2);
                    while (tmp.Length != 8)
                        tmp = '0' + tmp;
                    decomp += tmp;
                }
            }
            foreach (char c in decomp)
            {
                p += c;
                if (code.ContainsValue(p))
                {
                    char tmp = code.FirstOrDefault(x => x.Value == p).Key;
                    if (tmp == 'E')
                        break;
                    new_prog += tmp;
                    p = "";
                }
            }
            return new_prog;
        }

        private void generate_huffman_code_rec(Tree t, string path, Dictionary<char, string> encodings)
        {
            if (t.left != null)
            {
                generate_huffman_code_rec(t.left, path + "0", encodings);
                generate_huffman_code_rec(t.right, path + "1", encodings);
            }
            else
                encodings.Add(t.c, path);
        }

        private void generate_huffman_code(string program)
        {
            Dictionary<char, int> counts = new Dictionary<char, int>();
            counts.Add('<', 0);
            counts.Add('>', 0);
            counts.Add('+', 0);
            counts.Add('-', 0);
            counts.Add('.', 0);
            counts.Add(',', 0);
            counts.Add('[', 0);
            counts.Add(']', 0);
            counts.Add('E', 1);

            for (int i = 0; i < program.Length; i++)
                counts[program[i]] += 1;

            Dictionary<char, string> huffman_code = new Dictionary<char, string>();
            huffman_code.Add('<', "");
            huffman_code.Add('>', "");
            huffman_code.Add('+', "");
            huffman_code.Add('-', "");
            huffman_code.Add('.', "");
            huffman_code.Add(',', "");
            huffman_code.Add('[', "");
            huffman_code.Add(']', "");
            huffman_code.Add('E', "");

            List<Tree> queue = new List<Tree>();
            for (int i = 0; i < counts.Count; i++)
                queue.Add(new Tree(null, null, counts.ElementAt(i).Value, counts.ElementAt(i).Key));

            while (queue.Count > 1)
            {
                Tree t1 = queue.OrderBy(k => k.frequency).ElementAt(0);
                Tree t2 = queue.OrderBy(k => k.frequency).ElementAt(1);

                queue.Remove(t1);
                queue.Remove(t2);

                Tree t3 = new Tree(null, null, t1.frequency + t2.frequency, ' ');
                t3.left = t1;
                t3.right = t2;

                queue.Add(t3);

            }
            generate_huffman_code_rec(queue.ElementAt(0), "", encodings);
        }
    }
}
