﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Brainfuck
{
    public class Tree
    {
        public Tree left;
        public Tree right;
        public int frequency;
        public char c;

        public Tree(Tree left, Tree right, int frequency, char c)
        {
            this.left = left;
            this.right = right;
            this.frequency = frequency;
            this.c = c;
        }
    }
}
