﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Brainfuck
{
    class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new IDE());

  /*          string code = System.IO.File.ReadAllText("code.txt");

            code = Brainfuck.generate_text_from_text("Coucou les sups c'est vos ACDC qui vous parlent!");
            //code = "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.";
            Console.WriteLine("Before shorten_code: " + code.Length + " chars...");
            Console.WriteLine(code);

            code = Brainfuck.shorten_code(code);
            Console.WriteLine("After shorten_code: " + code.Length + " chars...");
            Console.WriteLine(code);
           // code = "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.";
            HuffmanCode h = new HuffmanCode(code);
            h.print_code();

            Console.WriteLine(h.huffman_program);
            Console.WriteLine(h.get_brainfuck_from_huffman(h.huffman_program) == h.program);

            Console.WriteLine("After Huffman : " + h.huffman_program.Length + " chars...");



            Brainfuck.interpret(code);*/
        }

        
    }
}
