﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Brainfuck
{
    class Brainfuck
    {
        public static void interpret(string code)
        {
            int position = 15000;
            int[] cells = new int[30000];
            int borne_sup = 256;
            int borne_inf = 0;

            for (int i = 0; i < cells.Length; i++)
            {
                cells[i] = 0;
            }

            List<int> posboucle = new List<int>();

            for (int i = 0; i < code.Length; i++)
            {
                switch (code[i])
                {
                    case '>':
                        position = position == cells.Length - 1 ? 0 : position + 1;
                        break;
                    case '<':
                        position = position > 0 ? position - 1 : cells.Length - 1;
                        break;
                    case '+':
                        cells[position] = cells[position] == borne_sup ? borne_inf : cells[position] + 1;
                        break;
                    case '-':
                        cells[position] = cells[position] == borne_inf ? borne_sup : cells[position] - 1;
                        break;
                    case '.':
                        Console.Write((char)cells[position]);
                        break;
                    case ',':
                        cells[position] = (char)Console.ReadKey(true).KeyChar;
                        break;
                    case '[':
                        int pos = 0;
                        if (cells[position] == 0)
                        {
                            for (int j = 1; j < code.Length; j++)
                            {
                                if (code[i + j] == '[')
                                    pos++;
                                else if (code[i + j] == ']' && pos != 0)
                                    pos--;
                                else if (code[i + j] == ']' && pos == 0)
                                {
                                    i += j + 1;
                                    break;
                                }
                            }
                        }
                        else
                            posboucle.Add(i);
                        break;
                    case ']':
                        if (cells[position] != 0)
                            i = posboucle[posboucle.Count - 1];
                        else
                            posboucle.RemoveAt(posboucle.Count - 1);
                        break;
                }
            }
        }
        public static string generate_code_from_text(string text)
        {
            string program = "";
            foreach (char c in text)
            {
                program += generate_loop_number(c);
            }
            return program;
        }

        private static string generate_loop_number(int n)
        {
            return new string('+', n) + ".[-]";
        }

        private static string build_mult(int a, int b)
        {
            return ">" + new string('+', a) + "[<" + new string('+', b) + ">-]<";
        }

        public static string shorten_code(string program)
        {
            string new_prog = "";

            for (int i = 0; i < program.Length; i++)
            {
                if (program[i] == '+')
                {
                    int buff = i++;
                    int cpt = 1;
                    while (program[i] == '+')
                    {
                        i++;
                        cpt++;
                    }

                    bool enter = false;
                    for (int k = 9; k > 5; k--)
                    {
                        if (cpt % k == 0)
                        {
                            new_prog += build_mult(k, cpt / k);
                            enter = true;
                            i = buff + cpt - 1;
                            break;
                        }
                    }

                    if (!enter)
                    {
                        i = buff;
                        new_prog += "+";
                    }
                }
                else
                {
                    new_prog += program[i];
                }
            }
            return new_prog;
        }
    }
}
